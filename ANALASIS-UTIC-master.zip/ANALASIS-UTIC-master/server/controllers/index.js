const usuarios=require('./usuarios');
const fotografias=require('./fotografias');

module.exports={
    usuarios,
    fotografias
}